﻿// Change program name below to switch games

using var game = new NobertStudios.Programs.Base_Game();
game.Run();